const tg = window.Telegram?.WebApp;
if (tg) { tg.ready(); tg.expand(); }

const data = {
  cases: {eyebrow:"КОЛЛЕКЦИЯ КЕЙСОВ",title:"Популярные кейсы",items:[
    ["Starter Case","🎁","Бесплатно","Базовые коллекционные подарки","🎁","⭐","🧸"],
    ["Star Case","🌟","25 ★","Звёздные и тематические предметы","🌟","💫","✨"],
    ["Ocean Case","🐬","50 ★","Морская коллекция","🐬","🐚","🪼"],
    ["Royal Case","👑","100 ★","Премиальная королевская коллекция","👑","💎","🏆"],
    ["Mystery Case","🪄","150 ★","Сюрпризы из загадочной коллекции","🪄","🔮","🎭"],
    ["Galaxy Case","🌌","250 ★","Космические и редкие предметы","🌌","🪐","☄️"],
    ["Myth Case","🐉","350 ★","Мифические существа и артефакты","🐉","🗡️","💠"],
    ["Diamond Case","💎","500 ★","Драгоценная коллекция","💎","👑","🏅"]
  ]},
  eggs: {eyebrow:"КОЛЛЕКЦИЯ ЯИЦ",title:"Выбери яйцо",items:[
    ["Classic Egg","🥚","Бесплатно","Классические сюрпризы","🐣","🐥","🥚"],
    ["Gold Egg","🌟","30 ★","Золотая коллекция","🌟","👑","💛"],
    ["Dragon Egg","🐉","75 ★","Драконьи предметы","🐉","🔥","🦎"],
    ["Crystal Egg","💎","120 ★","Кристальные предметы","💎","🔷","✨"]
  ]},
  slots: {eyebrow:"ИГРОВОЙ ЗАЛ",title:"Слоты • демо",items:[
    ["Lucky 7","🎰","Демо","Демонстрационный слот","7️⃣","🍒","⭐"],
    ["Fruit Spin","🍒","Демо","Фруктовый слот","🍒","🍋","🍇"],
    ["Star Spin","⭐","Демо","Звёздный слот","⭐","🌟","💫"],
    ["Neon Spin","💜","Демо","Неоновый слот","💜","🔮","⚡"]
  ]},
  upgrade: {eyebrow:"УЛУЧШЕНИЕ",title:"Апгрейд предметов",items:[
    ["Starter Upgrade","⚡","Демо","Пробный экран улучшения","🎁","💎","⭐"],
    ["Star Upgrade","✨","Демо","Пробный экран улучшения","🌟","👑","💠"]
  ]}
};
let activeTab = "cases";
let selected = null;
const $ = id => document.getElementById(id);
const balance = Number(localStorage.getItem("yupi_demo_balance") || 0);
$("balance").textContent = balance;

function render(tab="cases") {
  activeTab = tab;
  const section = data[tab];
  $("eyebrow").textContent = section.eyebrow;
  $("catalogTitle").textContent = section.title;
  $("catalog").innerHTML = section.items.map((item,i)=>`
    <button class="case-card" data-index="${i}">
      <div class="case-art">${item[1]}</div>
      <div class="case-name">${item[0]}</div>
      <div class="case-sub">${item[3]}</div>
      <div class="case-bottom"><span class="price">${item[2]}</span><span class="chance">СОДЕРЖИМОЕ →</span></div>
    </button>`).join("");
  document.querySelectorAll(".case-card").forEach(card =>
    card.addEventListener("click",()=>openDetails(section.items[Number(card.dataset.index)]))
  );
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
}
function openDetails(item) {
  selected = item;
  $("openCase").style.display = "block";
  $("modalVisual").textContent = item[1];
  $("modalTag").textContent = activeTab.toUpperCase();
  $("modalTitle").textContent = item[0];
  $("modalDescription").textContent = item[3] + ". Демонстрационный список возможных предметов:";
  $("prizes").innerHTML = item.slice(4).map((gift,i)=>`<div class="prize"><b>${gift}</b><small>${["Обычный","Редкий","Эпический"][i]}</small></div>`).join("");
  $("spinResult").textContent = "";
  $("openCase").textContent = activeTab==="slots" || activeTab==="upgrade" ? "Запустить демо" : `Открыть • ${item[2]}`;
  $("modal").classList.add("show");
}
function closeModal() {$("modal").classList.remove("show")}
$("tabs").addEventListener("click",e=>{
  const btn=e.target.closest("[data-tab]");
  if(btn) render(btn.dataset.tab);
});
document.querySelectorAll(".bottom-item").forEach(btn=>btn.addEventListener("click",()=>{
  const tab=btn.dataset.tab;
  document.querySelectorAll(".bottom-item").forEach(x=>x.classList.toggle("active",x===btn));
  if(tab==="home") render("cases");
  else if(tab==="profile") {
    $("modalVisual").textContent="👤";$("modalTag").textContent="ПРОФИЛЬ";$("modalTitle").textContent="Твой профиль";
    $("modalDescription").textContent="Демо-профиль YupiStars. Подключение Telegram ID и истории операций появится после настройки сервера.";
    $("prizes").innerHTML="";$("spinResult").textContent="Баланс: "+$("balance").textContent+" ★";$("openCase").style.display="none";$("modal").classList.add("show");
  } else render(tab);
}));
$("openCase").addEventListener("click",()=>{
  if(!selected) return;
  const pool=selected.slice(4);
  const prize=pool[Math.floor(Math.random()*pool.length)];
  $("spinResult").textContent="🎉 Демо-результат: "+prize+" — поздравляем!";
});
$("closeModal").addEventListener("click",closeModal);
$("modal").addEventListener("click",e=>{if(e.target===$("modal"))closeModal()});
$("topupBtn").addEventListener("click",()=>{
  $("modalVisual").textContent="⭐";$("modalTag").textContent="ПОПОЛНЕНИЕ";$("modalTitle").textContent="Пополнение Stars";
  $("modalDescription").textContent="Оплата пока не подключена. Здесь можно будет добавить безопасную оплату через Telegram Stars.";
  $("prizes").innerHTML="";$("spinResult").textContent="";$("openCase").style.display="none";$("modal").classList.add("show");
});
$("profileBtn").addEventListener("click",()=>document.querySelector('.bottom-item[data-tab="profile"]').click());
$("openCase").style.display="block";
render("cases");
